# Termux Command Bridge — Fabric 1.21.11

A client-side Fabric mod plus a small Python website for Termux. You type a Minecraft command into the website and press **Run command**; it enters an authenticated queue, and the mod sends it to the Minecraft server as your currently connected player when the bridge is enabled.

**Important boundaries:** this sends Minecraft commands only; it does not run Android, Termux, Windows, or shell commands. It cannot grant itself OP or bypass server permission checks. The server decides whether your player is allowed to use each command. The mod is disabled by default, and you must press **J** in-game to enable/disable it.

## Files

- `src/` — Fabric client mod source for Minecraft Java 1.21.11.
- `termux-server/bridge_server.py` — small Python HTTP server and authenticated queue.
- `termux-server/index.html` — the command entry website.

## 1. Start the website in Termux

In Termux, install Python if needed:

```sh
pkg update
pkg install python
```

Copy the `termux-server` folder onto the Android device, open Termux in that folder, and start the server:

```sh
python bridge_server.py --host 0.0.0.0 --port 8765
```

The first launch generates `bridge_token.txt` and prints the token in the terminal. Keep it private. Open `http://127.0.0.1:8765` in the Android browser. If you open the website from a different device on the same Wi-Fi, use the Android device's local Wi-Fi IP instead, for example `http://192.168.1.25:8765`.

Enter the token into the website's **Bridge token** field. The website keeps it in that browser tab's session storage, not long-term local storage.

## 2. Build the mod JAR

You need **JDK 21** and **Gradle 9.3.0 or compatible** installed, plus internet access for Gradle to download the Minecraft/Fabric build dependencies. In a terminal opened in this project folder, run:

```sh
gradle build
```

The distributable JAR should appear in `build/libs/termux-command-bridge-1.0.0.jar`. If you use an IDE such as IntelliJ IDEA, open this folder as a Gradle project and run its `build` task.

This source bundle does not include a precompiled JAR or the binary Gradle wrapper because the build dependencies could not be downloaded in this environment.

## 3. Install and configure the mod

1. Install Fabric Loader for Minecraft **1.21.11**, Fabric API for **1.21.11**, and use Java 21.
2. Put `termux-command-bridge-1.0.0.jar` in the Minecraft instance's `mods` folder.
3. Launch once, then close Minecraft. The mod creates `config/termux-command-bridge.properties`.
4. Edit that file. Paste the exact token from `bridge_token.txt`:

```properties
baseUrl=http://127.0.0.1:8765
token=PASTE_YOUR_TOKEN_HERE
pollMillis=750
```

Use `127.0.0.1` only when Minecraft and Termux are on the same device. If Termux is on your phone and Minecraft runs on a separate PC, set `baseUrl` to the phone's local Wi-Fi address, such as `http://192.168.1.25:8765`. The PC and phone must be on the same trusted network. Restart Minecraft after editing the config.

## 4. Use it

1. Join a world or server.
2. Press **J**. An in-game message confirms whether the bridge is enabled or disabled. You can change the key in **Options → Controls → Key Binds**.
3. Open the website, enter a command such as `/time set day`, then press **Run command**.
4. The website shows whether it was queued and whether the mod sent it. “Sent” means the client sent it to the server; it does not confirm the command succeeded. The server's permissions still apply.
5. Press **J** again to disable polling. Commands already sitting in the website queue remain there until the bridge is enabled again; commands already fetched locally are cleared when disabled or disconnected.

The mod sends the command packet directly rather than putting the command into your local chat input line. Server replies and command feedback may still appear in chat.

## Security notes

- Treat the token like a password. Anyone who has it can queue Minecraft commands to your client while the bridge is enabled.
- The included server uses plain HTTP. Use it only on a trusted local network. **Do not port-forward port 8765 or expose this server directly to the public internet.** HTTP does not encrypt the token in transit.
- Stop the server with **Ctrl+C** when finished. Rotate the token by stopping the server, deleting `bridge_token.txt`, and restarting it; then update the mod config and webpage token.
- The website does not run shell commands and the server code does not invoke a shell.

## Troubleshooting

- **Website loads but commands do not run:** confirm the mod is enabled with **J**, you are connected to a world/server, and the website's token matches the mod config.
- **401 / token rejected:** copy the full token from `bridge_token.txt` to both places, then reload the page and restart Minecraft.
- **Website works on the phone but not on the PC:** use the phone's local Wi-Fi IP in both the browser URL and `baseUrl`; check Android's network/firewall settings.
- **Command denied:** this bridge does not elevate permissions. The connected player must have permission to use that command on the server.
- **Build fails:** verify JDK 21 is selected and Gradle can access Fabric/Maven repositories. This source is pinned to Minecraft 1.21.11, Fabric API 0.141.6+1.21.11, Loader 0.18.6, and Loom 1.15.5.

## License

MIT — see `LICENSE`.
