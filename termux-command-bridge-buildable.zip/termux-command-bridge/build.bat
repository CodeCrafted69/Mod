@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle is not installed. Install JDK 21 and Gradle 9.3.0+, or open this folder in IntelliJ IDEA.
  exit /b 1
)
gradle build %*
