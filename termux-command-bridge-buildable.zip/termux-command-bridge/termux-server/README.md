# Run the command website in Termux

1. Copy this folder to the Android device and open it in Termux.
2. Run `pkg update` and `pkg install python` if Python is not installed.
3. Start the web server:

   ```sh
   python bridge_server.py --host 0.0.0.0 --port 8765
   ```

4. Open `http://127.0.0.1:8765` on the same device. From another device on the same Wi-Fi, use the Android device's local Wi-Fi IP, e.g. `http://192.168.1.25:8765`.
5. Copy the token printed at startup into the website and the Minecraft mod config. The server saves it in `bridge_token.txt`.

Stop with Ctrl+C. Do not port-forward this HTTP server to the internet; the token is not encrypted in transit. The server only queues Minecraft command strings and never executes shell commands.
