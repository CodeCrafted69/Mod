#!/usr/bin/env python3
"""Small, token-authenticated command queue for the Termux Command Bridge mod.

This server only queues Minecraft commands. It never executes shell commands.
"""
from __future__ import annotations

import argparse
import hmac
import json
import os
import queue
import secrets
import threading
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from itertools import count
from pathlib import Path
from urllib.parse import urlparse

HERE = Path(__file__).resolve().parent
TOKEN_FILE = HERE / "bridge_token.txt"
MAX_COMMAND_LENGTH = 2048
MAX_BODY_LENGTH = 8192
MAX_PENDING = 100
pending: queue.Queue[dict] = queue.Queue(maxsize=MAX_PENDING)
result_lock = threading.Lock()
recent_results: deque[dict] = deque(maxlen=50)
next_id = count(1)


def load_or_create_token() -> str:
    if TOKEN_FILE.exists():
        token = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if len(token) >= 32:
            return token
    token = secrets.token_urlsafe(32)
    TOKEN_FILE.write_text(token + "\n", encoding="utf-8")
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except OSError:
        pass
    return token


TOKEN = load_or_create_token()


class BridgeHandler(BaseHTTPRequestHandler):
    server_version = "TermuxCommandBridge/1.0"

    def log_message(self, fmt: str, *args) -> None:
        # Don't log auth headers or command bodies.
        print("[http] " + (fmt % args))

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self) -> bool:
        supplied = self.headers.get("Authorization", "")
        expected = "Bearer " + TOKEN
        if not hmac.compare_digest(supplied, expected):
            self._send_json(401, {"error": "unauthorized", "message": "Enter the bridge token."})
            return False
        return True

    def _read_json(self) -> dict | None:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._send_json(400, {"error": "invalid_content_length"})
            return None
        if length < 1 or length > MAX_BODY_LENGTH:
            self._send_json(413, {"error": "invalid_body_size"})
            return None
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._send_json(400, {"error": "invalid_json"})
            return None
        if not isinstance(value, dict):
            self._send_json(400, {"error": "expected_json_object"})
            return None
        return value

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/" or path == "/index.html":
            try:
                body = (HERE / "index.html").read_bytes()
            except OSError:
                self.send_error(500, "Web interface missing")
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)
            return

        if path not in ("/api/next", "/api/status"):
            self._send_json(404, {"error": "not_found"})
            return
        if not self._authorized():
            return

        if path == "/api/next":
            try:
                item = pending.get_nowait()
                self._send_json(200, {"id": item["id"], "command": item["command"]})
            except queue.Empty:
                self._send_json(200, {"id": None, "command": None})
            return

        with result_lock:
            results = list(recent_results)
        self._send_json(200, {"queued": pending.qsize(), "results": results})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path not in ("/api/queue", "/api/result"):
            self._send_json(404, {"error": "not_found"})
            return
        if not self._authorized():
            return
        data = self._read_json()
        if data is None:
            return

        if path == "/api/queue":
            command = data.get("command")
            if not isinstance(command, str):
                self._send_json(400, {"error": "command_required"})
                return
            command = command.strip()
            if command.startswith("/"):
                command = command[1:].strip()
            if not command:
                self._send_json(400, {"error": "empty_command"})
                return
            if len(command) > MAX_COMMAND_LENGTH or any(ch in command for ch in ("\n", "\r", "\0")):
                self._send_json(400, {"error": "command_too_long_or_multiline"})
                return
            item = {"id": next(next_id), "command": command}
            try:
                pending.put_nowait(item)
            except queue.Full:
                self._send_json(429, {"error": "queue_full", "message": "The bridge queue is full."})
                return
            self._send_json(202, {"ok": True, "id": item["id"], "message": "Command queued."})
            return

        result_id = data.get("id")
        status = data.get("status")
        message = data.get("message", "")
        if not isinstance(result_id, int) or not isinstance(status, str):
            self._send_json(400, {"error": "id_and_status_required"})
            return
        if status not in ("sent", "error", "rejected"):
            self._send_json(400, {"error": "invalid_status"})
            return
        if not isinstance(message, str):
            message = ""
        result = {"id": result_id, "status": status, "message": message[:300]}
        with result_lock:
            recent_results.append(result)
        self._send_json(200, {"ok": True})


def main() -> None:
    parser = argparse.ArgumentParser(description="Termux Command Bridge web queue")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address; default allows trusted LAN devices")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()

    server = ThreadingHTTPServer((args.host, args.port), BridgeHandler)
    print("\n=== Termux Command Bridge ===")
    print(f"Web page: http://127.0.0.1:{args.port}/")
    print(f"Token file: {TOKEN_FILE}")
    print("Access token (paste into the webpage and the Minecraft mod config):")
    print(TOKEN)
    if args.host == "0.0.0.0":
        print("LAN mode: use this device's Wi-Fi IP from another device.")
    print("Security: do not port-forward this HTTP server to the public internet.")
    print("Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping bridge...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
