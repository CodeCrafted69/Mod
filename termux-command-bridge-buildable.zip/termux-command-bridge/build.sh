#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Install JDK 21 and Gradle 9.3.0+, or open this folder in IntelliJ IDEA." >&2
  exit 1
fi
exec gradle build "$@"
